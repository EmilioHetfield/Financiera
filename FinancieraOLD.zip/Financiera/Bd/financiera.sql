-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-11-2024 a las 23:33:10
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `financiera`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `crear_prestamo` (IN `p_cliente_id` BIGINT, IN `p_monto` DECIMAL(10,2), IN `p_plazo` INT, IN `p_tasa_interes` DECIMAL(5,2), IN `p_ruta_firma_prestamo` VARCHAR(255), IN `p_tipo_pagare` ENUM('normal','con_aval'), IN `p_nombre_cliente` VARCHAR(255), IN `p_ruta_firma_cliente` VARCHAR(255), IN `p_fecha_limite_pago` DATE, IN `p_nombre_aval` VARCHAR(255), IN `p_ruta_firma_aval` VARCHAR(255))   BEGIN
  DECLARE prestamo_id BIGINT;

  -- Insertar el préstamo
  INSERT INTO prestamos (cliente_id, monto, plazo, tasa_interes, estado, ruta_firma_prestamo)
  VALUES (p_cliente_id, p_monto, p_plazo, p_tasa_interes, 'Pendiente', p_ruta_firma_prestamo);

  -- Obtener el ID del préstamo recién creado
  SET prestamo_id = LAST_INSERT_ID();

  -- Insertar el pagaré asociado
  INSERT INTO pagares (prestamo_id, tipo_pagare, nombre_cliente, monto, fecha, ruta_firma_cliente, nombre_aval, ruta_firma_aval, fecha_limite_pago)
  VALUES (prestamo_id, p_tipo_pagare, p_nombre_cliente, p_monto, CURDATE(), p_ruta_firma_cliente, p_nombre_aval, p_ruta_firma_aval, p_fecha_limite_pago);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `registrar_pago` (IN `p_prestamo_id` BIGINT, IN `p_monto` DECIMAL(10,2), IN `p_fecha_pago` DATE)   BEGIN
  -- Insertar el pago
  INSERT INTO pagos (prestamo_id, monto, fecha_pago)
  VALUES (p_prestamo_id, p_monto, p_fecha_pago);

  -- Actualizar el estado del préstamo si se completa
  IF (SELECT SUM(monto) FROM pagos WHERE prestamo_id = p_prestamo_id) >= (SELECT monto FROM prestamos WHERE id = p_prestamo_id) THEN
    UPDATE prestamos SET estado = 'Completado' WHERE id = p_prestamo_id;
  END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autorizaciones`
--

CREATE TABLE `autorizaciones` (
  `id` bigint(20) NOT NULL,
  `prestamo_id` bigint(20) NOT NULL,
  `autorizador_id` bigint(20) NOT NULL,
  `fecha_autorizacion` date NOT NULL,
  `estado` enum('Pendiente','Aprobado','Rechazado') NOT NULL DEFAULT 'Pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `autorizaciones`
--

TRUNCATE TABLE `autorizaciones`;
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` bigint(20) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `genero` char(1) NOT NULL,
  `firma` varchar(255) DEFAULT NULL,
  `id_vendedor` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `clientes`
--

TRUNCATE TABLE `clientes`;
--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre_completo`, `fecha_nacimiento`, `email`, `telefono`, `genero`, `firma`, `id_vendedor`) VALUES
(4, 'Eduardo Brandon Flores Ramírez', '1992-08-02', 'ejemplo@ejemplo.mx', '5553428400', 'M', 'firma_cliente_674a33ec53ab5.png', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direcciones`
--

CREATE TABLE `direcciones` (
  `id` bigint(20) NOT NULL,
  `usuario_id` bigint(20) DEFAULT NULL,
  `cliente_id` bigint(20) DEFAULT NULL,
  `direccion` varchar(255) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `codigo_postal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `direcciones`
--

TRUNCATE TABLE `direcciones`;
--
-- Volcado de datos para la tabla `direcciones`
--

INSERT INTO `direcciones` (`id`, `usuario_id`, `cliente_id`, `direccion`, `ciudad`, `estado`, `codigo_postal`) VALUES
(2, NULL, 4, 'C. Falsa 445', 'Ciudad de México', 'Distrito Federal', '11001');

--
-- Disparadores `direcciones`
--
DELIMITER $$
CREATE TRIGGER `validar_direccion` BEFORE INSERT ON `direcciones` FOR EACH ROW BEGIN
  IF (NEW.usuario_id IS NOT NULL AND NEW.cliente_id IS NOT NULL) OR (NEW.usuario_id IS NULL AND NEW.cliente_id IS NULL) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Una dirección debe pertenecer a un usuario o a un cliente, pero no a ambos ni a ninguno.';
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagares`
--

CREATE TABLE `pagares` (
  `id` bigint(20) NOT NULL,
  `prestamo_id` bigint(20) NOT NULL,
  `tipo_pagare` enum('normal','con_aval') NOT NULL,
  `nombre_cliente` varchar(255) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `fecha_limite_pago` date NOT NULL,
  `ruta_firma_cliente` varchar(255) NOT NULL,
  `nombre_aval` varchar(255) DEFAULT NULL,
  `ruta_firma_aval` varchar(255) DEFAULT NULL,
  `multa` decimal(10,2) DEFAULT 0.00,
  `estado` enum('Pendiente','Pagado','Vencido') NOT NULL DEFAULT 'Pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `pagares`
--

TRUNCATE TABLE `pagares`;
--
-- Volcado de datos para la tabla `pagares`
--

INSERT INTO `pagares` (`id`, `prestamo_id`, `tipo_pagare`, `nombre_cliente`, `monto`, `fecha`, `fecha_limite_pago`, `ruta_firma_cliente`, `nombre_aval`, `ruta_firma_aval`, `multa`, `estado`) VALUES
(1, 1, 'con_aval', 'Eduardo Brandon Flores Ramírez', 28000.00, '2024-11-29', '2024-12-07', 'firma_cliente_674a335a320e3.png', 'Carlos Rojas Duarte', 'firma_aval_674a335a3241f.png', 0.00, 'Pendiente'),
(2, 1, 'con_aval', 'Eduardo Brandon Flores Ramírez', 28000.00, '2024-11-29', '2024-12-07', 'firma_cliente_674a33711c9db.png', 'Carlos Rojas Duarte', 'firma_aval_674a33711cb74.png', 0.00, 'Pendiente'),
(3, 1, 'con_aval', 'Eduardo Brandon Flores Ramírez', 28000.00, '2024-11-29', '2024-12-07', 'firma_cliente_674a33ec53ab5.png', 'Carlos Rojas Duarte', 'firma_aval_674a33ec53be6.png', 0.00, 'Pendiente');

--
-- Disparadores `pagares`
--
DELIMITER $$
CREATE TRIGGER `validar_fecha_limite_pago` BEFORE INSERT ON `pagares` FOR EACH ROW BEGIN
  IF NEW.fecha_limite_pago < NEW.fecha THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La fecha límite de pago no puede ser anterior a la fecha de emisión del pagaré';
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` bigint(20) NOT NULL,
  `prestamo_id` bigint(20) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha_pago` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `pagos`
--

TRUNCATE TABLE `pagos`;
--
-- Disparadores `pagos`
--
DELIMITER $$
CREATE TRIGGER `actualizar_estado_prestamo` AFTER INSERT ON `pagos` FOR EACH ROW BEGIN
  DECLARE total_pagos DECIMAL(10,2);

  -- Calcular el total de pagos realizados para el préstamo
  SELECT SUM(monto) INTO total_pagos FROM pagos WHERE prestamo_id = NEW.prestamo_id;

  -- Actualizar el estado del préstamo si el total de pagos alcanza el monto del préstamo
  IF total_pagos >= (SELECT monto FROM prestamos WHERE id = NEW.prestamo_id) THEN
    UPDATE prestamos SET estado = 'Completado' WHERE id = NEW.prestamo_id;
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prestamos`
--

CREATE TABLE `prestamos` (
  `id` bigint(20) NOT NULL,
  `cliente_id` bigint(20) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `plazo` int(11) NOT NULL,
  `tasa_interes` decimal(5,2) NOT NULL,
  `estado` enum('Pendiente','Completado') NOT NULL DEFAULT 'Pendiente',
  `ruta_firma_prestamo` varchar(255) NOT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado_solicitud` enum('pendiente','aprobado','rechazado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `prestamos`
--

TRUNCATE TABLE `prestamos`;
--
-- Volcado de datos para la tabla `prestamos`
--

INSERT INTO `prestamos` (`id`, `cliente_id`, `monto`, `plazo`, `tasa_interes`, `estado`, `ruta_firma_prestamo`, `fecha_solicitud`, `estado_solicitud`) VALUES
(1, 4, 28000.00, 12, 10.00, 'Pendiente', 'firma_cliente_674a33ec53ab5.png', '2024-11-28 23:57:30', 'aprobado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo_usuario` enum('vendedor','autorizador','master') NOT NULL,
  `profile_image` varchar(255) DEFAULT 'assets/img/profile-img.jpg',
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncar tablas antes de insertar `usuarios`
--

TRUNCATE TABLE `usuarios`;
--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `password`, `tipo_usuario`, `profile_image`, `telefono`) VALUES
(1, 'Eduardo Brandon Flores Ramirez', 'admin', '0192023a7bbd73250516f069df18b500', 'master', 'assets/img/profile/profile_1_1732919475.png', '2211125677'),
(2, 'Juan Vendedor', 'vendedor', 'a60c36fc7c825e68bb5371a0e08f828a', 'vendedor', 'assets/img/profile-img.jpg', NULL),
(3, 'Pedro Autorizador', 'autorizador', '3b9117bf8366a250de4354239ba0c051', 'autorizador', 'assets/img/profile-img.jpg', NULL),
(4, 'Liam Aaron Flores Flores', 'liamaron', 'efc31a907e850fd2beb823059940ddd1', 'vendedor', 'assets/img/profile-img.jpg', '2224809995');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autorizaciones`
--
ALTER TABLE `autorizaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prestamo_id` (`prestamo_id`),
  ADD KEY `autorizador_id` (`autorizador_id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_vendedor` (`id_vendedor`);

--
-- Indices de la tabla `direcciones`
--
ALTER TABLE `direcciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `pagares`
--
ALTER TABLE `pagares`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prestamo_id` (`prestamo_id`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prestamo_id` (`prestamo_id`);

--
-- Indices de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autorizaciones`
--
ALTER TABLE `autorizaciones`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `direcciones`
--
ALTER TABLE `direcciones`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pagares`
--
ALTER TABLE `pagares`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `autorizaciones`
--
ALTER TABLE `autorizaciones`
  ADD CONSTRAINT `autorizaciones_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`),
  ADD CONSTRAINT `autorizaciones_ibfk_2` FOREIGN KEY (`autorizador_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `fk_cliente_vendedor` FOREIGN KEY (`id_vendedor`) REFERENCES `usuarios` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `direcciones`
--
ALTER TABLE `direcciones`
  ADD CONSTRAINT `direcciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `direcciones_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Filtros para la tabla `pagares`
--
ALTER TABLE `pagares`
  ADD CONSTRAINT `pagares_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`);

--
-- Filtros para la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
