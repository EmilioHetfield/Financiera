<?php
// Configuración de la base de datos
//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "financiera";
//$port = 3306;

$servername = "localhost";
$username = "droopyst_test";
$password = "M3nd0z@2020.";
$dbname = "droopyst_testFinanciera";


try {
    // Crear una nueva instancia de PDO
    $dsn = "mysql:host=$servername;port=$port;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Lanzar excepciones en caso de error
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Modo de fetch por defecto
        PDO::ATTR_EMULATE_PREPARES   => false,                  // Desactivar emulaci��n de prepared statements
    ];

    $conn = new PDO($dsn, $username, $password, $options);

    // Opcional: Establecer el modo de error a excepciones
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Manejar excepciones de conexi��n
    die("Error en la conexi��n: " . $e->getMessage());
}
?>