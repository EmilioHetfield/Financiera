<?php
require_once __DIR__ . '/../config.php';

error_log("Iniciando proceso...");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        // Iniciar sesión y obtener ID del vendedor
        session_start();
        if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
            throw new Exception("Sesión no válida");
        }
        $id_vendedor = $_SESSION['user']['id'];
        
        // Debug de datos recibidos
        error_log("Datos POST recibidos: " . print_r($_POST, true));
        error_log("ID del vendedor: " . $id_vendedor);
        
        // Procesar datos del cliente
        $stmt = $conn->prepare("INSERT INTO clientes (
            nombre_completo, 
            fecha_nacimiento, 
            email, 
            telefono, 
            genero,
            id_vendedor
        ) VALUES (?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $_POST['nombre_completo'],
            $_POST['fecha_nacimiento'],
            $_POST['email'],
            $_POST['telefono'],
            $_POST['genero'],
            $id_vendedor
        ]);
        
        $cliente_id = $conn->lastInsertId();
        error_log("Cliente insertado con ID: " . $cliente_id);
        
        // Procesar dirección
        $stmt = $conn->prepare("INSERT INTO direcciones (cliente_id, direccion, ciudad, estado, codigo_postal) 
                               VALUES (?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $cliente_id,
            $_POST['direccion'],
            $_POST['ciudad'],
            $_POST['estado'],
            $_POST['codigo_postal']
        ]);
        
        error_log("Dirección insertada");
        
        // Insertar datos del préstamo
        $stmt = $conn->prepare("INSERT INTO prestamos (
            cliente_id, 
            monto, 
            tasa_interes,
            fecha_solicitud
        ) VALUES (?, ?, ?, NOW())");
        
        $stmt->execute([
            $cliente_id,
            $_POST['monto'],
            $_POST['tasa_interes']
        ]);
        
        $prestamo_id = $conn->lastInsertId();
        error_log("Préstamo insertado con ID: " . $prestamo_id);
        
        // Procesar firma
        if (isset($_POST['firma']) && !empty($_POST['firma'])) {
            error_log("Procesando firma...");
            
            // Crear directorio con ruta absoluta
            $upload_dir = realpath(__DIR__ . '/../uploads/firmas/');
            if (!$upload_dir) {
                $upload_dir = __DIR__ . '/../uploads/firmas/';
                error_log("Creando directorio en: " . $upload_dir);
                
                if (!file_exists($upload_dir)) {
                    if (!mkdir($upload_dir, 0777, true)) {
                        error_log("Error al crear el directorio de firmas");
                        throw new Exception("No se pudo crear el directorio para las firmas");
                    }
                }
            }
            
            // Asegurar que el directorio termine con separador
            $upload_dir = rtrim($upload_dir, '/\\') . DIRECTORY_SEPARATOR;
            
            // Procesar datos de la firma
            $firma_data = $_POST['firma'];
            error_log("Longitud de datos de firma: " . strlen($firma_data));
            
            if (strpos($firma_data, 'data:image/png;base64,') !== false) {
                $firma_data = str_replace('data:image/png;base64,', '', $firma_data);
                $firma_data = str_replace(' ', '+', $firma_data);
                $firma_decodificada = base64_decode($firma_data);
                
                if ($firma_decodificada === false) {
                    error_log("Error al decodificar la firma");
                    throw new Exception("Error al decodificar los datos de la firma");
                }
                
                // Generar nombre único
                $nombre_firma = 'firma_' . $cliente_id . '_' . time() . '.png';
                $ruta_firma = $upload_dir . $nombre_firma;
                
                error_log("Intentando guardar firma en: " . $ruta_firma);
                
                // Intentar guardar el archivo
                $bytes_escritos = file_put_contents($ruta_firma, $firma_decodificada);
                
                if ($bytes_escritos !== false) {
                    error_log("Firma guardada exitosamente. Bytes escritos: " . $bytes_escritos);
                    
                    // Verificar que el archivo existe
                    if (file_exists($ruta_firma)) {
                        error_log("Archivo verificado en: " . $ruta_firma);
                        
                        // Actualizar registro del cliente
                        $stmt = $conn->prepare("UPDATE clientes SET firma = ? WHERE id = ?");
                        $stmt->execute([$nombre_firma, $cliente_id]);
                        error_log("Base de datos actualizada con nombre de firma: " . $nombre_firma);
                    } else {
                        throw new Exception("El archivo de firma no se encontró después de guardarlo");
                    }
                } else {
                    error_log("Error al escribir el archivo. Permisos del directorio: " . substr(sprintf('%o', fileperms($upload_dir)), -4));
                    throw new Exception("Error al guardar el archivo de firma");
                }
            } else {
                error_log("Formato de datos de firma inválido");
                throw new Exception("Formato de firma inválido");
            }
        } else {
            error_log("No se recibieron datos de firma");
        }
        
        $conn->commit();
        error_log("Transacción completada exitosamente");
        
        echo json_encode([
            'success' => true,
            'message' => 'Cliente y préstamo registrados exitosamente',
            'cliente_id' => $cliente_id,
            'prestamo_id' => $prestamo_id
        ]);
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Error en el proceso: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error al registrar: ' . $e->getMessage()
        ]);
    }
} else {
    error_log("Método no permitido");
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
?>