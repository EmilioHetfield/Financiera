<?php
function getDashboardData($conn) {
    try {
        $data = [
            'totals' => [],
            'worker_loans' => [],
            'client_loans' => []
        ];

        // Consulta para totales de clientes
        $sql = "SELECT COUNT(*) as total_clients FROM clientes";
        $stmt = $conn->query($sql);
        $totals = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Consulta para totales de usuarios por tipo
        $sql2 = "SELECT 
            COUNT(CASE WHEN tipo_usuario = 'vendedor' THEN 1 END) as total_sellers,
            COUNT(CASE WHEN tipo_usuario = 'autorizador' THEN 1 END) as total_collectors
            FROM usuarios";
        $stmt = $conn->query($sql2);
        $user_counts = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Combinar resultados de totales
        $data['totals'] = array_merge($totals, $user_counts);

        // Consulta para trabajadores (sin usar la tabla direcciones)
        $sql3 = "SELECT 
            u.id,
            u.nombre as full_name,
            'No disponible' as mobile_number,  -- Valor por defecto ya que no tenemos teléfono
            u.tipo_usuario as id_type,
            u.usuario as nickname
            FROM usuarios u
            WHERE u.tipo_usuario IN ('vendedor', 'autorizador')
            ORDER BY u.id DESC
            LIMIT 10";
        $stmt = $conn->query($sql3);
        $data['worker_loans'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Consulta para préstamos de clientes
        $sql4 = "SELECT 
            p.id,
            c.nombre_completo as first_name,
            c.id as client_number,
            COALESCE(pg.tipo_pagare, 'No especificado') as loan_type,
            p.monto as requested_amount
            FROM prestamos p
            JOIN clientes c ON p.cliente_id = c.id
            LEFT JOIN pagares pg ON p.id = pg.prestamo_id
            ORDER BY p.fecha_solicitud DESC
            LIMIT 10";
        $stmt = $conn->query($sql4);
        $data['client_loans'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Debug: Verificar datos antes de retornar
        error_log("Datos obtenidos exitosamente: " . print_r($data, true));
        
        return $data;

    } catch (PDOException $e) {
        error_log("Error en getDashboardData: " . $e->getMessage());
        return [
            'totals' => [
                'total_clients' => 0,
                'total_sellers' => 0,
                'total_collectors' => 0
            ],
            'worker_loans' => [],
            'client_loans' => []
        ];
    }
}

function getNotifications($conn, $user_id) {
    try {
        $sql = "SELECT n.*, 
                       l.loan_type,
                       l.loan_status,
                       c.first_name,
                       c.middle_name,
                       c.last_name,
                       c.form_fill_date
                FROM notifications n
                LEFT JOIN loan_information l ON n.loan_id = l.id
                LEFT JOIN clientes c ON l.client_id = c.id
                WHERE n.user_id = :user_id 
                AND n.notification_status = 0
                ORDER BY n.created_at DESC
                LIMIT 5";

        $stmt = $conn->prepare($sql);
        $stmt->execute([':user_id' => $user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return [];
    }
}