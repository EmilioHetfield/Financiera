<?php
require_once __DIR__ . '/../config.php';
require_once 'pagare_functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();
    
    try {
        $pagareManager = new PagareManager($conn);
        $resultado = $pagareManager->registrarPagare($_POST);
        
        echo json_encode($resultado);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
} 