<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['prestamo_id'])) {
        throw new Exception('ID de préstamo no proporcionado');
    }
    
    $sql = "SELECT COUNT(*) FROM pagares WHERE prestamo_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$data['prestamo_id']]);
    $existe = $stmt->fetchColumn() > 0;
    
    echo json_encode([
        'success' => true,
        'existe' => $existe
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 