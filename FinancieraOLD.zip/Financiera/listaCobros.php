<?php
session_start();
include 'config.php';
include 'functions/dashboard_queries.php';
require_once 'functions/auth.php';
verificarAcceso(['master', 'vendedor']);

$date_today = date('Y-m-d');

$nickname = $user_info['id'];

$sql = "SELECT c.*, li.*, d.* FROM contratos as c LEFT JOIN loan_information as li on li.collector_id = c.id_cliente LEFT JOIN direcciones as d on d.id = c.domicilio_id where li.collector_id = :nickname and loan_status = 'Aceptado'";

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nickname' => $nickname
    ]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}

?>

<?php include '../Financiera/views/head.php'; ?>

<?php include '../Financiera/views/header.php'; ?>

<?php include '../Financiera/views/nav_menu.php'; ?>

<!-- ======= Main ======= -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Cobros</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                <li class="breadcrumb-item active">Cobros</li>
            </ol>
        </nav>
    </div>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-8">
                <div class="container mt-5">
                    <h1 class="text-center mb-4">Clientes para Cobrar Hoy</h1>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Cliente</th>
                                <th>Monto Restante</th>
                                <th>Pago del Día</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($result as $row) : ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['first_name'] . " " . $row['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['monto_total']-$row['total_pagado']); ?></td>
                                    <td><?php echo htmlspecialchars($row['pago_semanal']); ?></td>
                                    <td>
                                        <a href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode($row['direccion'] . ', ' . $row['city'] . ', ' . $row['state']); ?>" target="_blank" class="btn btn-secondary">Ver en Google Maps</a>
                                        <a href="" target="_blank" class="btn btn-primary">Cobrar</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</main>
</body>
<?php include '../Financiera/views/footer.php'; ?>

</html>