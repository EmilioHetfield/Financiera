<?php
session_start();
include 'config.php';
include 'functions/dashboard_queries.php';
require_once 'functions/auth.php';
verificarAcceso(['master', 'vendedor']);

// Construir la consulta base
$sql = "SELECT 
            p.id, 
            p.monto,
            p.plazo,
            p.tasa_interes, 
            c.nombre_completo,
            p.fecha_solicitud,
            c.id_vendedor
        FROM prestamos p 
        JOIN clientes c ON p.cliente_id = c.id 
        WHERE p.estado_solicitud = 'aprobado' 
        AND p.estado = 'Pendiente'
        AND NOT EXISTS (
            SELECT 1 
            FROM pagares pg 
            WHERE pg.prestamo_id = p.id
        )";

// Agregar filtro por vendedor si no es master
if ($_SESSION['user']['tipo_usuario'] !== 'master') {
    $sql .= " AND c.id_vendedor = :vendedor_id";
}

$sql .= " ORDER BY p.fecha_solicitud DESC";

try {
    $stmt = $conn->prepare($sql);
    
    // Bind del ID del vendedor si es necesario
    if ($_SESSION['user']['tipo_usuario'] !== 'master') {
        $stmt->bindValue(':vendedor_id', $_SESSION['user']['id'], PDO::PARAM_INT);
    }
    
    $stmt->execute();
    $prestamos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($prestamos) && $_SESSION['user']['tipo_usuario'] !== 'master') {
        $_SESSION['error'] = "No hay préstamos pendientes de pagaré para este vendedor.";
    } elseif (empty($prestamos)) {
        $_SESSION['error'] = "No hay préstamos pendientes de pagaré en el sistema.";
    }
    
} catch (PDOException $e) {
    error_log("Error en la consulta: " . $e->getMessage());
    $_SESSION['error'] = "Error al cargar los préstamos. Por favor, intente más tarde.";
    $prestamos = [];
}

include '../Financiera/views/head.php';
include '../Financiera/views/header.php';
include '../Financiera/views/nav_menu.php';
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Pagaré con Aval</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                <li class="breadcrumb-item active">Pagaré con Aval</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Formulario de Pagaré</h5>

                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form id="pagareForm" class="needs-validation" novalidate>
                            <input type="hidden" name="tipo_pagare" value="con_aval">
                            
                            <!-- Selección de Préstamo -->
                            <div class="mb-3">
                                <label for="prestamo_id" class="form-label">Seleccionar Préstamo *</label>
                                <select class="form-select" id="prestamo_id" name="prestamo_id" required>
                                    <option value="">Seleccione un préstamo...</option>
                                    <?php foreach ($prestamos as $prestamo): ?>
                                        <option value="<?php echo htmlspecialchars($prestamo['id']); ?>"
                                                data-cliente="<?php echo htmlspecialchars($prestamo['nombre_completo']); ?>"
                                                data-monto="<?php echo htmlspecialchars($prestamo['monto']); ?>"
                                                data-plazo="<?php echo htmlspecialchars($prestamo['plazo']); ?>"
                                                data-tasa="<?php echo htmlspecialchars($prestamo['tasa_interes']); ?>">
                                            <?php 
                                            echo htmlspecialchars(
                                                $prestamo['nombre_completo'] . 
                                                ' - $' . number_format($prestamo['monto'], 2) . 
                                                ' - Plazo: ' . $prestamo['plazo'] . ' meses' .
                                                ' - Fecha: ' . date('d/m/Y', strtotime($prestamo['fecha_solicitud']))
                                            ); 
                                            ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">Por favor seleccione un préstamo</div>
                            </div>

                            <!-- Datos del Cliente -->
                            <div class="mb-3">
                                <label for="nombre_cliente" class="form-label">Nombre del Cliente *</label>
                                <input type="text" class="form-control" id="nombre_cliente" name="nombre_cliente" readonly required>
                            </div>

                            <div class="mb-3">
                                <label for="monto" class="form-label">Monto *</label>
                                <input type="number" class="form-control" id="monto" name="monto" step="0.01" readonly required>
                            </div>

                            <!-- Fechas -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="fecha" class="form-label">Fecha de Emisión *</label>
                                        <input type="date" class="form-control" id="fecha" name="fecha" required>
                                        <div class="invalid-feedback">Por favor seleccione la fecha de emisión</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="fecha_limite_pago" class="form-label">Fecha Límite de Pago *</label>
                                        <input type="date" class="form-control" id="fecha_limite_pago" name="fecha_limite_pago" required>
                                        <div class="invalid-feedback">Por favor seleccione la fecha límite</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Datos del Aval -->
                            <div class="mb-3">
                                <label for="nombre_aval" class="form-label">Nombre del Aval *</label>
                                <input type="text" class="form-control" id="nombre_aval" name="nombre_aval" required>
                                <div class="invalid-feedback">Por favor ingrese el nombre del aval</div>
                            </div>

                            <!-- Firmas -->
                            <div class="mb-4">
                                <label class="form-label">Firma del Cliente *</label>
                                <canvas id="signatureCanvasCliente" class="border mb-2 w-100" style="height: 200px;"></canvas>
                                <input type="hidden" id="firma_cliente" name="firma_cliente">
                                <button type="button" class="btn btn-secondary btn-sm" onclick="clearCanvas('signatureCanvasCliente')">
                                    Limpiar Firma Cliente
                                </button>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Firma del Aval *</label>
                                <canvas id="signatureCanvasAval" class="border mb-2 w-100" style="height: 200px;"></canvas>
                                <input type="hidden" id="firma_aval" name="firma_aval">
                                <button type="button" class="btn btn-secondary btn-sm" onclick="clearCanvas('signatureCanvasAval')">
                                    Limpiar Firma Aval
                                </button>
                            </div>

                            <!-- Botones -->
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary" id="btnSubmit">
                                    <i class="bi bi-save"></i> Guardar Pagaré
                                </button>
                                <a href="index.php" class="btn btn-secondary ms-2">
                                    <i class="bi bi-x-circle"></i> Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include '../Financiera/views/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('pagareForm');
    const prestamoSelect = document.getElementById('prestamo_id');
    
    // Configurar canvas para firmas
    setupCanvas('signatureCanvasCliente');
    setupCanvas('signatureCanvasAval');
    
    // Función para verificar si ya existe un pagaré
    async function verificarPagareExistente(prestamoId) {
        try {
            const response = await fetch('functions/verificar_pagare.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ prestamo_id: prestamoId })
            });
            
            const data = await response.json();
            return data.existe;
        } catch (error) {
            console.error('Error al verificar pagaré:', error);
            return false;
        }
    }
    
    // Verificar al cambiar el préstamo seleccionado
    prestamoSelect.addEventListener('change', async function() {
        const prestamoId = this.value;
        if (prestamoId) {
            const existe = await verificarPagareExistente(prestamoId);
            if (existe) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Advertencia',
                    text: 'Ya existe un pagaré registrado para este préstamo'
                });
                this.value = ''; // Limpiar selección
                return;
            }
            
            // Actualizar campos si no existe pagaré
            const selectedOption = this.options[this.selectedIndex];
            document.getElementById('nombre_cliente').value = selectedOption.dataset.cliente;
            document.getElementById('monto').value = selectedOption.dataset.monto;
        }
    });

    // Validar fechas
    document.getElementById('fecha_limite_pago').addEventListener('change', function() {
        const fechaEmision = new Date(document.getElementById('fecha').value);
        const fechaLimite = new Date(this.value);
        
        if (fechaLimite <= fechaEmision) {
            this.setCustomValidity('La fecha límite debe ser posterior a la fecha de emisión');
        } else {
            this.setCustomValidity('');
        }
    });

    // Manejar envío del formulario
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Verificar nuevamente antes de enviar
        const prestamoId = prestamoSelect.value;
        const existe = await verificarPagareExistente(prestamoId);
        if (existe) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Ya existe un pagaré registrado para este préstamo'
            });
            return;
        }
        
        if (!form.checkValidity()) {
            e.stopPropagation();
            form.classList.add('was-validated');
            return;
        }

        const btnSubmit = document.getElementById('btnSubmit');
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<i class="bi bi-hourglass-split"></i> Procesando...';

        // Obtener datos de firmas
        const firmaCliente = document.getElementById('signatureCanvasCliente').toDataURL('image/png');
        const firmaAval = document.getElementById('signatureCanvasAval').toDataURL('image/png');
        
        document.getElementById('firma_cliente').value = firmaCliente;
        document.getElementById('firma_aval').value = firmaAval;

        try {
            const formData = new FormData(this);
            const response = await fetch('functions/procesar_pagare.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                Swal.fire({
                    icon: 'success',
                    title: '¡Éxito!',
                    text: result.message,
                    confirmButtonText: 'Aceptar'
                }).then(() => {
                    window.location.href = 'index.php';
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: result.message
                });
            }
        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error al procesar la solicitud'
            });
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = '<i class="bi bi-save"></i> Guardar Pagaré';
        }
    });
});

function setupCanvas(canvasId) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');
    let drawing = false;

    function setCanvasSize() {
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#000';
    }

    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    function startDrawing(e) {
        drawing = true;
        draw(e);
    }

    function stopDrawing() {
        drawing = false;
        ctx.beginPath();
    }

    function draw(e) {
        if (!drawing) return;
        
        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX || e.touches[0].clientX) - rect.left;
        const y = (e.clientY || e.touches[0].clientY) - rect.top;
        
        ctx.lineTo(x, y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x, y);
    }

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    canvas.addEventListener('touchstart', (e) => {
        e.preventDefault();
        startDrawing(e.touches[0]);
    });
    canvas.addEventListener('touchmove', (e) => {
        e.preventDefault();
        draw(e.touches[0]);
    });
    canvas.addEventListener('touchend', stopDrawing);
}

function clearCanvas(canvasId) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}
</script>

</body>
</html>