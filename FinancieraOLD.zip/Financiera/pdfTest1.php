<?php
require('fpdf/fpdf.php');
session_start();
    include 'config.php';
    include 'functions/dashboard_queries.php';

// Clase personalizada para el Pagaré
class PagarePDF extends FPDF {
    function Header() {
        // Título
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'FINANCIERA CREDI SIGUE', 0, 1, 'C');
        $this->SetFont('Arial', '', 14);
        $this->Cell(0, 10, 'Pagaré', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer() {
        // Pie de página
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Página ' . $this->PageNo(), 0, 0, 'C');
    }

    function Body($data) {
        $this->SetFont('Arial', '', 12);

        // Monto
        $this->Cell(0, 10, "Monto: $" . number_format($data['monto'], 2) . " (" . $this->convertirNumeroATexto($data['monto']) . "/100, M.N.)", 0, 1);

        // Deudor
        $this->MultiCell(0, 10, "Por virtud del presente pagaré, " . $data['nombre_cliente'] . " (en lo sucesivo denominado(a) como el “Deudor”), prometo pagar y pagaré incondicionalmente a la orden de Financiera CREDI SIGUE, S.A. de C.V., o a cualquier otra persona que posea el presente pagaré, a quien en lo sucesivo se le denominará el “Tenedor”.", 0, 'J');

        // Dirección
        $this->Cell(0, 10, "Domicilio: " . $data['direccion_tenedor'], 0, 1);

        // Fechas
        $this->Cell(0, 10, "Fecha de emisión: " . $data['fecha'], 0, 1);
        $this->Cell(0, 10, "Fecha límite de pago: " . $data['fecha_limite_pago'], 0, 1);

        // Firma
        $this->Ln(20);
        $this->Cell(0, 10, "Firma del Deudor:", 0, 1);
        if (!empty($data['ruta_firma_cliente'])) {
            $this->Image($data['ruta_firma_cliente'], 10, $this->GetY(), 40);
        }
    }

    function convertirNumeroATexto($numero) {
        // Función para convertir el número en texto
        // Ejemplo: 150.75 -> "Ciento cincuenta pesos con setenta y cinco centavos"
        // Implementa o utiliza librerías externas si es necesario.
        return "ciento cincuenta"; // Placeholder
    }
}

// Crear el PDF
$data = [
    'monto' => 1500.75,
    'nombre_cliente' => 'Juan Pérez',
    'direccion_tenedor' => 'Av. Siempre Viva #123, Ciudad Gótica',
    'fecha' => '2024-12-02',
    'fecha_limite_pago' => '2025-01-01',
    'ruta_firma_cliente' => 'ruta/firma.png'
];

$pdf = new PagarePDF();
$pdf->AddPage();
$pdf->Body($data);
$pdf->Output('D', 'Pagare.pdf');
?>
