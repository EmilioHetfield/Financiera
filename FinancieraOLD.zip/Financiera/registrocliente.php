<?php
session_start();
require_once 'config.php';
require_once 'functions/dashboard_queries.php';
require_once 'functions/auth.php';
verificarAcceso(['master', 'vendedor']);

include 'views/head.php';
include 'views/header.php';
include 'views/nav_menu.php';
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Clientes</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Inicio</a></li>
                <li class="breadcrumb-item active">Registrar cliente</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Registro de Nuevo Cliente</h5>

                        <form id="registroClienteForm" class="needs-validation" novalidate>
                            <!-- Datos personales -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="nombre_completo" class="form-label">Nombre Completo *</label>
                                        <input type="text" class="form-control" id="nombre_completo"
                                            name="nombre_completo" required>
                                        <div class="invalid-feedback">Por favor ingrese el nombre completo</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento *</label>
                                        <input type="date" class="form-control" id="fecha_nacimiento"
                                            name="fecha_nacimiento" required>
                                        <div class="invalid-feedback">Por favor seleccione la fecha de nacimiento</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email *</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                        <div class="invalid-feedback">Por favor ingrese un email válido</div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="telefono" class="form-label">Teléfono *</label>
                                        <input type="tel" class="form-control" id="telefono" name="telefono" required
                                            pattern="[0-9]{10}" maxlength="10">
                                        <div class="invalid-feedback">Por favor ingrese un teléfono válido (10 dígitos)
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="genero" class="form-label">Género *</label>
                                        <select class="form-select" id="genero" name="genero" required>
                                            <option value="">Seleccione...</option>
                                            <option value="M">Masculino</option>
                                            <option value="F">Femenino</option>
                                        </select>
                                        <div class="invalid-feedback">Por favor seleccione el género</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Dirección -->
                            <div class="row mt-4">
                                <h5>Dirección</h5>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="direccion" class="form-label">Calle y Número *</label>
                                        <input type="text" class="form-control" id="direccion" name="direccion"
                                            required>
                                        <div class="invalid-feedback">Por favor ingrese la dirección</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="ciudad" class="form-label">Ciudad *</label>
                                        <input type="text" class="form-control" id="ciudad" name="ciudad" required>
                                        <div class="invalid-feedback">Por favor ingrese la ciudad</div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="estado" class="form-label">Estado *</label>
                                        <input type="text" class="form-control" id="estado" name="estado" required>
                                        <div class="invalid-feedback">Por favor ingrese el estado</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="codigo_postal" class="form-label">Código Postal *</label>
                                        <input type="text" class="form-control" id="codigo_postal" name="codigo_postal"
                                            required pattern="[0-9]{5}" maxlength="5">
                                        <div class="invalid-feedback">Por favor ingrese un código postal válido (5
                                            dígitos)</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Datos del préstamo -->
                            <div class="row mt-4">
                                <h5>Información del Préstamo</h5>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="monto" class="form-label">Monto del Préstamo *</label>
                                        <input type="number" step="0.01" class="form-control" id="monto" name="monto" required>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="plazo" class="form-label">Plazo (meses) *</label>
                                        <input type="number" min="1" class="form-control" id="plazo" name="plazo"
                                            required>
                                        <div class="invalid-feedback">Por favor ingrese el plazo</div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="tasa_interes" class="form-label">Tasa de Interés (%) *</label>
                                        <input type="number" step="0.01" class="form-control" id="tasa_interes" name="tasa_interes" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Firma del cliente -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="firmaCanvas" class="form-label">Firma del Cliente *</label>
                                        <canvas id="firmaCanvas" 
                                                width="400" 
                                                height="200" 
                                                class="border rounded" 
                                                style="touch-action: none;">
                                        </canvas>
                                        <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="limpiarFirma()">
                                            <i class="bi bi-eraser"></i> Limpiar Firma
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Registrar Cliente
                                    </button>
                                    <a href="index.php" class="btn btn-secondary ms-2">
                                        <i class="bi bi-x-circle"></i> Cancelar
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'views/footer.php'; ?>

<!-- Scripts específicos -->
<script src="assets/js/scriptcreacioncliente.js"></script>

<script>
// Validaciones adicionales del formulario
document.getElementById('telefono').addEventListener('input', function(e) {
    // Solo permitir números
    this.value = this.value.replace(/[^0-9]/g, '');
});

document.getElementById('codigo_postal').addEventListener('input', function(e) {
    // Solo permitir números
    this.value = this.value.replace(/[^0-9]/g, '');
});

// Mostrar alerta de confirmación antes de cancelar
document.querySelector('a[href="index.php"]').addEventListener('click', function(e) {
    e.preventDefault();
    if (confirm('¿Está seguro de cancelar el registro? Los datos no guardados se perderán.')) {
        window.location.href = this.href;
    }
});

// Dentro del evento submit del formulario
document.getElementById('registroClienteForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    // Debug
    console.log('Iniciando envío del formulario');
    
    const firmaBase64 = canvas.toDataURL('image/png');
    const formData = new FormData(this);
    formData.append('firma', firmaBase64);

    try {
        console.log('Enviando datos al servidor...');
        const response = await fetch('functions/API_Functions.php', {
            method: 'POST',
            body: formData
        });
        
        console.log('Respuesta recibida');
        const data = await response.json();
        console.log('Datos:', data);
        
        if (data.success) {
            alert('Cliente registrado exitosamente');
            window.location.href = 'index.php';
        } else {
            alert('Error en el registro: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al procesar la solicitud');
    }
});
</script>

</body>

</html>