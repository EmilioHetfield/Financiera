<?php
// Función para obtener las últimas 5 notificaciones de préstamos
function getUltimosPrestamos($conn) {
    try {
        $sql = "SELECT 
                p.id,
                p.fecha_solicitud,
                p.monto,
                p.estado_solicitud,
                c.nombre_completo as nombre_cliente
                FROM prestamos p
                JOIN clientes c ON p.cliente_id = c.id
                ORDER BY p.fecha_solicitud DESC
                LIMIT 5";
        
        $stmt = $conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener notificaciones: " . $e->getMessage());
        return [];
    }
}

// Obtener las notificaciones
$notificaciones = getUltimosPrestamos($conn);
$total_notificaciones = count($notificaciones);
?>

<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
        <a href="index.php" class="logo d-flex align-items-center">
            <span class="d-none d-lg-block">Financiera</span>
        </a>
        <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
    <nav class="header-nav ms-auto">
        <ul class="d-flex align-items-center">
            <!-- Notifications -->
            <li class="nav-item dropdown">
                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <?php if ($total_notificaciones > 0): ?>
                        <span class="badge bg-primary badge-number"><?php echo $total_notificaciones; ?></span>
                    <?php endif; ?>
                </a>

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                    <li class="dropdown-header">
                        Tienes <?php echo $total_notificaciones; ?> notificaciones nuevas
                    </li>

                    <?php foreach ($notificaciones as $notif): ?>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li class="notification-item">
                            <i class="bi bi-info-circle text-primary"></i>
                            <div>
                                <h4>Nuevo préstamo registrado</h4>
                                <p>Cliente: <?php echo htmlspecialchars($notif['nombre_cliente']); ?></p>
                                <p>Monto: $<?php echo number_format($notif['monto'], 2); ?></p>
                                <p>Estado: <?php echo ucfirst(htmlspecialchars($notif['estado_solicitud'])); ?></p>
                                <p class="text-muted small">
                                    <i class="bi bi-clock"></i> 
                                    <?php 
                                    $fecha = new DateTime($notif['fecha_solicitud']);
                                    echo $fecha->format('d/m/Y H:i'); 
                                    ?>
                                </p>
                            </div>
                        </li>
                    <?php endforeach; ?>

                    <?php if (empty($notificaciones)): ?>
                        <li class="notification-item">
                            <div>
                                <p class="text-muted">No hay notificaciones nuevas</p>
                            </div>
                        </li>
                    <?php endif; ?>

                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li class="dropdown-footer">
                        <a href="prestamos.php">Ver todos los préstamos</a>
                    </li>
                </ul>
            </li>

            <!-- User Nav -->
            <li class="nav-item dropdown pe-3">
                <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                    <span class="d-none d-md-block dropdown-toggle ps-2">
                        <?php 
                        echo isset($_SESSION['user']['nombre']) ? htmlspecialchars($_SESSION['user']['nombre']) : 'Usuario';
                        ?>
                    </span>
                </a>

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                    <li class="dropdown-header">
                        <h6>
                            <?php 
                            echo isset($_SESSION['user']['nombre']) ? htmlspecialchars($_SESSION['user']['nombre']) : 'Usuario';
                            ?>
                        </h6>
                        <span>
                            <?php 
                            echo isset($_SESSION['user']['tipo_usuario']) ? ucfirst(htmlspecialchars($_SESSION['user']['tipo_usuario'])) : 'Rol no definido';
                            ?>
                        </span>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center" href="users-profile.php">
                            <i class="bi bi-person"></i>
                            <span>Mi Perfil</span>
                        </a>
                    </li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center" href="logout.php">
                            <i class="bi bi-box-arrow-right"></i>
                            <span>Cerrar Sesión</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
</header>

    
